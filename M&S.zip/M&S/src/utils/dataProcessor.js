import * as XLSX from 'xlsx';

// Function to load data from Excel files
export const loadDataFromExcel = async (filePath) => {
  try {
    const response = await fetch(filePath);
    const data = await response.arrayBuffer();
    const workbook = XLSX.read(data, { type: 'array' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    return XLSX.utils.sheet_to_json(worksheet);
  } catch (error) {
    console.error(`Error loading data from ${filePath}:`, error);
    return [];
  }
};

// Function to load all data based on selected platforms and brands
export const loadAllData = async (brandName, competitors, selectedPlatforms) => {
  const dataFiles = {
    instagram: {
      'Marks & Spencer': [
        '/data/Insta_new_mandshashtags_cleaned.xlsx',
        '/data/Insta_new_marksandspencer_cleaned.xlsx'
      ],
      'Next Retail': [
        '/data/Insta_new_nexthashtags_cleaned.xlsx',
        '/data/Insta_new_nextofficial_cleaned_2.xlsx'
      ]
    },
    tiktok: {
      'Marks & Spencer': [
        '/data/dataset_tiktok-hashtag_M&S_cleaned.xlsx',
        '/data/dataset_tiktok_M&S_official_cleaned.xlsx'
      ],
      'Next Retail': [
        '/data/dataset_tiktok-hashtag_NextRetail_cleaned.xlsx',
        '/data/tiktok_NEXT_Official_cleaned.xlsx'
      ]
    },
    youtube: {
      'Marks & Spencer': [
        '/data/dataset_youtube-Hashtag_M&S 1_cleaned.xlsx',
        '/data/dataset_youtube-channel-scraper_M&S-official 1_cleaned.xlsx'
      ],
      'Next Retail': [
        '/data/dataset_youtube-Hashtag_Next 1_cleaned.xlsx',
        '/data/dataset_youtube-channel-scraper_NextRetail-Official 1_cleaned.xlsx'
      ]
    }
  };

  // Determine which brand is the main brand and which are competitors
  const brands = [brandName];
  if (competitors) {
    const competitorList = competitors.split(',').map(comp => comp.trim()).filter(comp => comp !== '');
    brands.push(...competitorList);
  }

  // Load data for each selected platform and brand
  const allData = {};
  
  for (const platform of selectedPlatforms) {
    allData[platform] = {};
    
    for (const brand of brands) {
      // Map user input brand names to dataset brand names
      let datasetBrand = '';
      if (brand.toLowerCase().includes('marks') || brand.toLowerCase().includes('spencer') || brand.toLowerCase().includes('m&s')) {
        datasetBrand = 'Marks & Spencer';
      } else if (brand.toLowerCase().includes('next')) {
        datasetBrand = 'Next Retail';
      } else {
        // Skip brands that don't match our dataset
        continue;
      }
      
      // Get files for this platform and brand
      const files = dataFiles[platform][datasetBrand] || [];
      
      // Load data from all files for this platform and brand
      const brandData = [];
      for (const file of files) {
        const data = await loadDataFromExcel(file);
        brandData.push(...data);
      }
      
      allData[platform][brand] = brandData;
    }
  }
  
  return allData;
};

// Calculate engagement metrics for Instagram
export const calculateInstagramEngagement = (data) => {
  return data.map(post => {
    const likes = post.likesCount || 0;
    const comments = post.commentsCount || 0;
    const engagement = likes + comments;
    const engagementRate = post.followersCount ? (engagement / post.followersCount) * 100 : null;
    
    return {
      ...post,
      engagement,
      engagementRate
    };
  });
};

// Calculate engagement metrics for TikTok
export const calculateTikTokEngagement = (data) => {
  return data.map(post => {
    const likes = post.diggCount || 0;
    const comments = post.commentCount || 0;
    const shares = post.shareCount || 0;
    const collects = post.collectCount || 0;
    const plays = post.playCount || 1; // Avoid division by zero
    
    const engagement = likes + comments + shares + collects;
    const engagementRate = (engagement / plays) * 100;
    
    return {
      ...post,
      engagement,
      engagementRate
    };
  });
};

// Calculate engagement metrics for YouTube
export const calculateYouTubeEngagement = (data) => {
  return data.map(video => {
    const likes = video.likeCount || 0;
    const comments = video.commentCount || 0;
    const views = video.viewCount || 1; // Avoid division by zero
    
    const engagement = likes + comments;
    const engagementRate = (engagement / views) * 100;
    
    return {
      ...video,
      engagement,
      engagementRate
    };
  });
};

// Perform sentiment analysis on text
export const analyzeSentiment = (text) => {
  if (!text) return 'neutral';
  
  // Simple sentiment analysis based on keywords
  // In a real implementation, you would use a more sophisticated NLP approach
  const positiveWords = ['great', 'good', 'excellent', 'amazing', 'love', 'best', 'beautiful', 'happy', 'perfect', 'awesome'];
  const negativeWords = ['bad', 'poor', 'terrible', 'awful', 'hate', 'worst', 'ugly', 'sad', 'disappointed', 'horrible'];
  
  const textLower = text.toLowerCase();
  let positiveScore = 0;
  let negativeScore = 0;
  
  positiveWords.forEach(word => {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    const matches = textLower.match(regex);
    if (matches) positiveScore += matches.length;
  });
  
  negativeWords.forEach(word => {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    const matches = textLower.match(regex);
    if (matches) negativeScore += matches.length;
  });
  
  if (positiveScore > negativeScore) return 'positive';
  if (negativeScore > positiveScore) return 'negative';
  return 'neutral';
};

// Extract hashtags from text
export const extractHashtags = (text) => {
  if (!text) return [];
  const matches = text.match(/#[a-zA-Z0-9_]+/g) || [];
  return matches;
};

// Process data for dashboard
export const processDataForDashboard = (allData) => {
  const result = {
    overallEngagement: {},
    engagementRates: {},
    topHashtags: {},
    sentimentAnalysis: {},
    competitorComparison: {}
  };
  
  // Process data for each platform
  Object.entries(allData).forEach(([platform, platformData]) => {
    // Process data for each brand
    Object.entries(platformData).forEach(([brand, brandData]) => {
      // Apply platform-specific processing
      let processedData;
      switch (platform) {
        case 'instagram':
          processedData = calculateInstagramEngagement(brandData);
          break;
        case 'tiktok':
          processedData = calculateTikTokEngagement(brandData);
          break;
        case 'youtube':
          processedData = calculateYouTubeEngagement(brandData);
          break;
        default:
          processedData = brandData;
      }
      
      // Add sentiment analysis
      processedData = processedData.map(item => {
        const textField = platform === 'instagram' ? 'caption' : 
                         platform === 'tiktok' ? 'text' : 'description';
        
        return {
          ...item,
          sentiment: analyzeSentiment(item[textField])
        };
      });
      
      // Store processed data
      if (!result.overallEngagement[platform]) result.overallEngagement[platform] = {};
      if (!result.engagementRates[platform]) result.engagementRates[platform] = {};
      if (!result.sentimentAnalysis[platform]) result.sentimentAnalysis[platform] = {};
      
      result.overallEngagement[platform][brand] = processedData.reduce((sum, item) => sum + (item.engagement || 0), 0);
      
      // Calculate average engagement rate
      const totalEngagementRate = processedData.reduce((sum, item) => sum + (item.engagementRate || 0), 0);
      result.engagementRates[platform][brand] = processedData.length ? totalEngagementRate / processedData.length : 0;
      
      // Count sentiments
      const sentiments = processedData.reduce((counts, item) => {
        counts[item.sentiment] = (counts[item.sentiment] || 0) + 1;
        return counts;
      }, { positive: 0, neutral: 0, negative: 0 });
      
      result.sentimentAnalysis[platform][brand] = sentiments;
      
      // Extract and count hashtags
      const textField = platform === 'instagram' ? 'caption' : 
                       platform === 'tiktok' ? 'text' : 'description';
      
      const allHashtags = processedData.flatMap(item => extractHashtags(item[textField]));
      const hashtagCounts = allHashtags.reduce((counts, tag) => {
        counts[tag] = (counts[tag] || 0) + 1;
        return counts;
      }, {});
      
      if (!result.topHashtags[platform]) result.topHashtags[platform] = {};
      result.topHashtags[platform][brand] = hashtagCounts;
    });
  });
  
  return result;
};

// Filter data by date range
export const filterByDateRange = (data, startDate, endDate) => {
  if (!startDate || !endDate) return data;
  
  const start = new Date(startDate);
  const end = new Date(endDate);
  
  return data.filter(item => {
    const itemDate = new Date(item.created_time || item.createTime || item.timestamp || item.publishedAt);
    return itemDate >= start && itemDate <= end;
  });
};

// Filter data by hashtag
export const filterByHashtag = (data, hashtag) => {
  if (!hashtag) return data;
  
  return data.filter(item => {
    const text = item.caption || item.text || item.description || '';
    return text.includes(hashtag);
  });
};

// Filter data by sentiment
export const filterBySentiment = (data, sentiment) => {
  if (!sentiment) return data;
  
  return data.filter(item => item.sentiment === sentiment);
};

// Get top performing content
export const getTopPerformingContent = (data, limit = 5) => {
  return [...data]
    .sort((a, b) => (b.engagement || 0) - (a.engagement || 0))
    .slice(0, limit);
};

// Get engagement over time
export const getEngagementOverTime = (data) => {
  // Group by date
  const engagementByDate = data.reduce((result, item) => {
    const date = new Date(item.created_time || item.createTime || item.timestamp || item.publishedAt);
    const dateStr = date.toISOString().split('T')[0];
    
    if (!result[dateStr]) {
      result[dateStr] = {
        date: dateStr,
        engagement: 0,
        posts: 0
      };
    }
    
    result[dateStr].engagement += (item.engagement || 0);
    result[dateStr].posts += 1;
    
    return result;
  }, {});
  
  // Convert to array and sort by date
  return Object.values(engagementByDate)
    .sort((a, b) => new Date(a.date) - new Date(b.date));
};

// Get word frequencies for word cloud
export const getWordFrequencies = (data, field) => {
  // Extract all words from the specified field
  const allWords = data
    .map(item => item[field] || '')
    .join(' ')
    .toLowerCase()
    .replace(/[^\w\s#]/g, '')
    .split(/\s+/)
    .filter(word => word.length > 3 && !word.startsWith('#'));
  
  // Count word frequencies
  const wordCounts = allWords.reduce((counts, word) => {
    counts[word] = (counts[word] || 0) + 1;
    return counts;
  }, {});
  
  // Convert to array format for word cloud
  return Object.entries(wordCounts)
    .map(([text, value]) => ({ text, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 100);
};
