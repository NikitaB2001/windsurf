import React, { useState } from 'react';
import Login from './components/Login/Login';
import SetupWizard from './components/Setup/SetupWizard';
import Dashboard from './components/Dashboard/Dashboard';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [setupData, setSetupData] = useState(null);
  const [appState, setAppState] = useState('login'); // login, setup, dashboard

  // Handle login
  const handleLogin = (userData) => {
    setUser(userData);
    setAppState('setup');
  };

  // Handle setup completion
  const handleSetupComplete = (data) => {
    setSetupData(data);
    setAppState('dashboard');
  };

  // Render the appropriate component based on app state
  const renderContent = () => {
    switch (appState) {
      case 'login':
        return <Login onLogin={handleLogin} />;
      case 'setup':
        return <SetupWizard onComplete={handleSetupComplete} />;
      case 'dashboard':
        return <Dashboard setupData={setupData} />;
      default:
        return <Login onLogin={handleLogin} />;
    }
  };

  return (
    <div className="app">
      {renderContent()}
    </div>
  );
}

export default App;
