import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import './Dashboard.css';

const EngagementInsights = ({ data, brandName, competitors }) => {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  // Parse competitors string into array
  const competitorList = competitors
    ? competitors.split(',').map(comp => comp.trim()).filter(comp => comp !== '')
    : [];

  // Format platform names for display
  const getPlatformName = (platformId) => {
    const platforms = {
      'instagram': 'Instagram',
      'tiktok': 'TikTok',
      'youtube': 'YouTube'
    };
    return platforms[platformId] || platformId;
  };

  // Create chart for engagement rates
  useEffect(() => {
    if (!data || Object.keys(data).length === 0) return;

    // Prepare data for chart
    const platforms = Object.keys(data);
    const brands = [brandName, ...competitorList].filter(brand => {
      // Only include brands that have data
      return platforms.some(platform => data[platform][brand] !== undefined);
    });

    const datasets = brands.map((brand, index) => {
      const colors = [
        'rgba(255, 87, 34, 0.7)',  // Main brand (orange)
        'rgba(33, 150, 243, 0.7)',  // Competitor 1 (blue)
        'rgba(76, 175, 80, 0.7)',   // Competitor 2 (green)
        'rgba(156, 39, 176, 0.7)'   // Competitor 3 (purple)
      ];

      return {
        label: brand,
        data: platforms.map(platform => {
          return data[platform][brand] || 0;
        }),
        backgroundColor: colors[index % colors.length],
        borderColor: colors[index % colors.length].replace('0.7', '1'),
        borderWidth: 1
      };
    });

    // Create or update chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    chartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: platforms.map(getPlatformName),
        datasets
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Engagement Rate by Platform'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                let label = context.dataset.label || '';
                if (label) {
                  label += ': ';
                }
                if (context.parsed.y !== null) {
                  label += context.parsed.y.toFixed(2) + '%';
                }
                return label;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Engagement Rate (%)'
            },
            ticks: {
              callback: function(value) {
                return value.toFixed(2) + '%';
              }
            }
          },
          x: {
            title: {
              display: true,
              text: 'Platform'
            }
          }
        }
      }
    });

    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, brandName, competitors, competitorList]);

  // Calculate platform-specific engagement formulas for display
  const engagementFormulas = {
    instagram: (
      <div className="formula-box">
        <h4>Instagram Engagement Rate</h4>
        <p className="formula">
          Engagement Rate = (likesCount + commentsCount) / followersCount * 100
        </p>
      </div>
    ),
    tiktok: (
      <div className="formula-box">
        <h4>TikTok Engagement Rate</h4>
        <p className="formula">
          Engagement Rate (%) = ((diggCount + commentCount + shareCount + collectCount) / playCount) * 100
        </p>
      </div>
    ),
    youtube: (
      <div className="formula-box">
        <h4>YouTube Engagement Rate</h4>
        <p className="formula">
          Engagement Rate (%) = ((likes + comments) / views) * 100
        </p>
      </div>
    )
  };

  return (
    <div className="dashboard-card">
      <div className="card-header">
        <div>
          <h2 className="card-title">Engagement Rate Insights</h2>
          <p className="card-subtitle">Comparison of engagement rates across platforms</p>
        </div>
      </div>
      
      <div className="card-content" style={{ height: 'auto' }}>
        <div style={{ height: '300px', marginBottom: '20px' }}>
          <canvas ref={chartRef}></canvas>
        </div>
        
        <div className="formulas-container">
          {Object.keys(data).map(platform => (
            engagementFormulas[platform] && (
              <div key={platform} className="formula-item">
                {engagementFormulas[platform]}
              </div>
            )
          ))}
        </div>
      </div>
    </div>
  );
};

export default EngagementInsights;
