import React from 'react';
import './Dashboard.css';

const DashboardHeader = ({ brandName }) => {
  // Get current date for display
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="dashboard-header">
      <div>
        <h1 className="dashboard-title">Analytics</h1>
        <p className="dashboard-subtitle">Detailed metrics and analysis for your social media performance.</p>
      </div>
      
      <div className="dashboard-controls">
        <div className="date-display">{currentDate}</div>
      </div>
    </div>
  );
};

export default DashboardHeader;
