import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import './Dashboard.css';

const BrandPerformance = ({ data, brandName, competitors }) => {
  const barChartRef = useRef(null);
  const lineChartRef = useRef(null);
  const barChartInstance = useRef(null);
  const lineChartInstance = useRef(null);

  // Parse competitors string into array
  const competitorList = competitors
    ? competitors.split(',').map(comp => comp.trim()).filter(comp => comp !== '')
    : [];

  // Format platform names for display
  const getPlatformName = (platformId) => {
    const platforms = {
      'instagram': 'Instagram',
      'tiktok': 'TikTok',
      'youtube': 'YouTube'
    };
    return platforms[platformId] || platformId;
  };

  // Create bar chart for total engagements
  useEffect(() => {
    if (!data || Object.keys(data).length === 0) return;

    // Prepare data for bar chart
    const platforms = Object.keys(data);
    const brands = [brandName, ...competitorList].filter(brand => {
      // Only include brands that have data
      return platforms.some(platform => data[platform][brand]);
    });

    const datasets = brands.map((brand, index) => {
      const colors = [
        'rgba(255, 87, 34, 0.7)',  // Main brand (orange)
        'rgba(33, 150, 243, 0.7)',  // Competitor 1 (blue)
        'rgba(76, 175, 80, 0.7)',   // Competitor 2 (green)
        'rgba(156, 39, 176, 0.7)'   // Competitor 3 (purple)
      ];

      return {
        label: brand,
        data: platforms.map(platform => {
          return data[platform][brand] || 0;
        }),
        backgroundColor: colors[index % colors.length],
        borderColor: colors[index % colors.length].replace('0.7', '1'),
        borderWidth: 1
      };
    });

    // Create or update bar chart
    if (barChartInstance.current) {
      barChartInstance.current.destroy();
    }

    const ctx = barChartRef.current.getContext('2d');
    barChartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: platforms.map(getPlatformName),
        datasets
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Total Engagements by Platform'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                let label = context.dataset.label || '';
                if (label) {
                  label += ': ';
                }
                if (context.parsed.y !== null) {
                  label += new Intl.NumberFormat().format(context.parsed.y);
                }
                return label;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Total Engagements'
            }
          },
          x: {
            title: {
              display: true,
              text: 'Platform'
            }
          }
        }
      }
    });

    // Create mock data for engagement trend over time
    // In a real implementation, this would use actual timestamp data from the dataset
    const mockTimeData = {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: brands.map((brand, index) => {
        const colors = [
          'rgb(255, 87, 34)',  // Main brand (orange)
          'rgb(33, 150, 243)',  // Competitor 1 (blue)
          'rgb(76, 175, 80)',   // Competitor 2 (green)
          'rgb(156, 39, 176)'   // Competitor 3 (purple)
        ];

        // Generate some mock data based on the actual engagement totals
        const baseValue = Object.values(data).reduce((sum, platformData) => {
          return sum + (platformData[brand] || 0);
        }, 0) / 6;

        return {
          label: brand,
          data: Array(6).fill().map((_, i) => {
            // Create a trend with some randomness
            return baseValue * (0.8 + (i * 0.05) + Math.random() * 0.3);
          }),
          borderColor: colors[index % colors.length],
          backgroundColor: 'transparent',
          tension: 0.3
        };
      })
    };

    // Create or update line chart
    if (lineChartInstance.current) {
      lineChartInstance.current.destroy();
    }

    const lineCtx = lineChartRef.current.getContext('2d');
    lineChartInstance.current = new Chart(lineCtx, {
      type: 'line',
      data: mockTimeData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Engagement Trend Over Time'
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Engagements'
            }
          },
          x: {
            title: {
              display: true,
              text: 'Month'
            }
          }
        }
      }
    });

    // Cleanup function
    return () => {
      if (barChartInstance.current) {
        barChartInstance.current.destroy();
      }
      if (lineChartInstance.current) {
        lineChartInstance.current.destroy();
      }
    };
  }, [data, brandName, competitors, competitorList]);

  return (
    <div className="dashboard-card">
      <div className="card-header">
        <div>
          <h2 className="card-title">Overall Brand Performance</h2>
          <p className="card-subtitle">Comparison of engagement metrics across platforms</p>
        </div>
      </div>
      
      <div className="card-content" style={{ display: 'flex', flexDirection: 'column', height: 'auto' }}>
        <div style={{ height: '300px', marginBottom: '20px' }}>
          <canvas ref={barChartRef}></canvas>
        </div>
        
        <div style={{ height: '300px' }}>
          <canvas ref={lineChartRef}></canvas>
        </div>
      </div>
    </div>
  );
};

export default BrandPerformance;
