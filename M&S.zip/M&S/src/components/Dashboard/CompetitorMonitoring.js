import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import './Dashboard.css';

const CompetitorMonitoring = ({ data, brandName, competitors }) => {
  const barChartRef = useRef(null);
  const stackedBarChartRef = useRef(null);
  const barChartInstance = useRef(null);
  const stackedBarChartInstance = useRef(null);

  // Parse competitors string into array
  const competitorList = competitors
    ? competitors.split(',').map(comp => comp.trim()).filter(comp => comp !== '')
    : [];

  // Create charts for competitor monitoring
  useEffect(() => {
    if (!data || Object.keys(data).length === 0 || competitorList.length === 0) return;

    // Extract engagement data for comparison
    const engagementData = data.overallEngagement;
    const platforms = Object.keys(engagementData);
    
    // Calculate total engagement per brand across all platforms
    const brands = [brandName, ...competitorList].filter(brand => {
      // Only include brands that have data
      return platforms.some(platform => 
        engagementData[platform] && engagementData[platform][brand]
      );
    });
    
    const totalEngagements = brands.map(brand => {
      return platforms.reduce((sum, platform) => {
        if (engagementData[platform] && engagementData[platform][brand]) {
          return sum + engagementData[platform][brand];
        }
        return sum;
      }, 0);
    });
    
    // Prepare data for bar chart
    const barData = {
      labels: brands,
      datasets: [{
        label: 'Total Engagement',
        data: totalEngagements,
        backgroundColor: brands.map((brand, index) => {
          const colors = [
            'rgba(255, 87, 34, 0.7)',  // Main brand (orange)
            'rgba(33, 150, 243, 0.7)',  // Competitor 1 (blue)
            'rgba(76, 175, 80, 0.7)',   // Competitor 2 (green)
            'rgba(156, 39, 176, 0.7)'   // Competitor 3 (purple)
          ];
          return colors[index % colors.length];
        }),
        borderColor: brands.map((brand, index) => {
          const colors = [
            'rgb(255, 87, 34)',  // Main brand (orange)
            'rgb(33, 150, 243)',  // Competitor 1 (blue)
            'rgb(76, 175, 80)',   // Competitor 2 (green)
            'rgb(156, 39, 176)'   // Competitor 3 (purple)
          ];
          return colors[index % colors.length];
        }),
        borderWidth: 1
      }]
    };
    
    // Create or update bar chart
    if (barChartInstance.current) {
      barChartInstance.current.destroy();
    }
    
    const barCtx = barChartRef.current.getContext('2d');
    barChartInstance.current = new Chart(barCtx, {
      type: 'bar',
      data: barData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          title: {
            display: true,
            text: 'Total Engagement Comparison'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return `Engagement: ${new Intl.NumberFormat().format(context.raw)}`;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Total Engagement'
            }
          },
          x: {
            title: {
              display: true,
              text: 'Brand'
            }
          }
        }
      }
    });
    
    // Extract sentiment data for stacked bar chart
    const sentimentData = data.sentimentAnalysis;
    
    // Prepare data for stacked bar chart
    const stackedBarData = {
      labels: brands,
      datasets: [
        {
          label: 'Positive',
          data: brands.map(brand => {
            let total = 0;
            platforms.forEach(platform => {
              if (sentimentData[platform] && 
                  sentimentData[platform][brand] && 
                  sentimentData[platform][brand].positive) {
                total += sentimentData[platform][brand].positive;
              }
            });
            return total;
          }),
          backgroundColor: 'rgba(76, 175, 80, 0.7)',
          borderColor: 'rgb(76, 175, 80)',
          borderWidth: 1
        },
        {
          label: 'Neutral',
          data: brands.map(brand => {
            let total = 0;
            platforms.forEach(platform => {
              if (sentimentData[platform] && 
                  sentimentData[platform][brand] && 
                  sentimentData[platform][brand].neutral) {
                total += sentimentData[platform][brand].neutral;
              }
            });
            return total;
          }),
          backgroundColor: 'rgba(33, 150, 243, 0.7)',
          borderColor: 'rgb(33, 150, 243)',
          borderWidth: 1
        },
        {
          label: 'Negative',
          data: brands.map(brand => {
            let total = 0;
            platforms.forEach(platform => {
              if (sentimentData[platform] && 
                  sentimentData[platform][brand] && 
                  sentimentData[platform][brand].negative) {
                total += sentimentData[platform][brand].negative;
              }
            });
            return total;
          }),
          backgroundColor: 'rgba(244, 67, 54, 0.7)',
          borderColor: 'rgb(244, 67, 54)',
          borderWidth: 1
        }
      ]
    };
    
    // Create or update stacked bar chart
    if (stackedBarChartInstance.current) {
      stackedBarChartInstance.current.destroy();
    }
    
    const stackedBarCtx = stackedBarChartRef.current.getContext('2d');
    stackedBarChartInstance.current = new Chart(stackedBarCtx, {
      type: 'bar',
      data: stackedBarData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: 'Sentiment Distribution Across Brands'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const label = context.dataset.label || '';
                const value = context.raw || 0;
                return `${label}: ${value}`;
              }
            }
          }
        },
        scales: {
          x: {
            stacked: true,
            title: {
              display: true,
              text: 'Brand'
            }
          },
          y: {
            stacked: true,
            beginAtZero: true,
            title: {
              display: true,
              text: 'Count'
            }
          }
        }
      }
    });
    
    // Cleanup function
    return () => {
      if (barChartInstance.current) {
        barChartInstance.current.destroy();
      }
      if (stackedBarChartInstance.current) {
        stackedBarChartInstance.current.destroy();
      }
    };
  }, [data, brandName, competitors, competitorList]);
  
  // Create comparison table data
  const createComparisonTableData = () => {
    if (!data || Object.keys(data).length === 0 || competitorList.length === 0) {
      return [];
    }
    
    const engagementData = data.overallEngagement;
    const platforms = Object.keys(engagementData);
    
    // Calculate metrics for each brand
    const tableData = [brandName, ...competitorList].map(brand => {
      const metrics = {
        brand,
        totalEngagement: 0,
        avgEngagementRate: 0,
        platforms: {}
      };
      
      // Calculate total engagement and platform-specific metrics
      platforms.forEach(platform => {
        if (engagementData[platform] && engagementData[platform][brand]) {
          metrics.totalEngagement += engagementData[platform][brand];
          
          // Store platform-specific engagement
          metrics.platforms[platform] = engagementData[platform][brand];
        }
      });
      
      // Calculate average engagement rate if available
      if (data.engagementRates) {
        let rateSum = 0;
        let rateCount = 0;
        
        platforms.forEach(platform => {
          if (data.engagementRates[platform] && 
              data.engagementRates[platform][brand]) {
            rateSum += data.engagementRates[platform][brand];
            rateCount++;
          }
        });
        
        metrics.avgEngagementRate = rateCount > 0 ? rateSum / rateCount : 0;
      }
      
      return metrics;
    });
    
    return tableData;
  };
  
  const comparisonTableData = createComparisonTableData();
  
  return (
    <div className="dashboard-card">
      <div className="card-header">
        <div>
          <h2 className="card-title">Competitor Monitoring</h2>
          <p className="card-subtitle">Comparison of engagement metrics across competitors</p>
        </div>
      </div>
      
      <div className="card-content" style={{ height: 'auto' }}>
        {competitorList.length > 0 ? (
          <>
            <div className="charts-container" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div style={{ height: '300px' }}>
                <canvas ref={barChartRef}></canvas>
              </div>
              
              <div style={{ height: '300px' }}>
                <canvas ref={stackedBarChartRef}></canvas>
              </div>
            </div>
            
            <div className="comparison-table-container" style={{ marginTop: '20px' }}>
              <h3>Engagement Metrics Comparison</h3>
              <div className="table-responsive">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Brand</th>
                      <th>Total Engagement</th>
                      <th>Avg. Engagement Rate</th>
                      {Object.keys(data.overallEngagement).map(platform => (
                        <th key={platform}>{platform.charAt(0).toUpperCase() + platform.slice(1)} Engagement</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {comparisonTableData.map((item, index) => (
                      <tr key={index} className={item.brand === brandName ? 'main-brand-row' : ''}>
                        <td>{item.brand}</td>
                        <td>{new Intl.NumberFormat().format(item.totalEngagement)}</td>
                        <td>{item.avgEngagementRate.toFixed(2)}%</td>
                        {Object.keys(data.overallEngagement).map(platform => (
                          <td key={platform}>
                            {item.platforms[platform] 
                              ? new Intl.NumberFormat().format(item.platforms[platform]) 
                              : 'N/A'}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : (
          <div className="no-data-message">
            No competitor data available. Add competitors in the setup to see comparison.
          </div>
        )}
      </div>
    </div>
  );
};

export default CompetitorMonitoring;
