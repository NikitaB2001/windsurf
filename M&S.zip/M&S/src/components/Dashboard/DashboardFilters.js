import React from 'react';
import './Dashboard.css';

const DashboardFilters = ({ filters, onFilterChange, platforms, brandName, competitors }) => {
  // Parse competitors string into array
  const competitorList = competitors
    ? competitors.split(',').map(comp => comp.trim()).filter(comp => comp !== '')
    : [];

  // Format platform names for display
  const getPlatformName = (platformId) => {
    const platforms = {
      'instagram': 'Instagram',
      'tiktok': 'TikTok',
      'youtube': 'YouTube'
    };
    return platforms[platformId] || platformId;
  };

  // Handle filter changes
  const handlePlatformChange = (e) => {
    onFilterChange({ platform: e.target.value });
  };

  const handleDateRangeChange = (field, value) => {
    onFilterChange({
      dateRange: {
        ...filters.dateRange,
        [field]: value
      }
    });
  };

  const handleHashtagChange = (e) => {
    onFilterChange({ hashtag: e.target.value });
  };

  const handleSentimentChange = (e) => {
    onFilterChange({ sentiment: e.target.value });
  };

  const handleBrandChange = (e) => {
    onFilterChange({ brand: e.target.value });
  };

  return (
    <div className="dashboard-filters">
      <div className="filters-row">
        <div className="filter-group">
          <label htmlFor="platform-filter">Platform</label>
          <select
            id="platform-filter"
            value={filters.platform}
            onChange={handlePlatformChange}
          >
            <option value="all">All Platforms</option>
            {platforms.map(platform => (
              <option key={platform} value={platform}>
                {getPlatformName(platform)}
              </option>
            ))}
          </select>
        </div>

        <div className="filter-group">
          <label htmlFor="start-date">Start Date</label>
          <input
            type="date"
            id="start-date"
            value={filters.dateRange.startDate || ''}
            onChange={(e) => handleDateRangeChange('startDate', e.target.value)}
          />
        </div>

        <div className="filter-group">
          <label htmlFor="end-date">End Date</label>
          <input
            type="date"
            id="end-date"
            value={filters.dateRange.endDate || ''}
            onChange={(e) => handleDateRangeChange('endDate', e.target.value)}
          />
        </div>

        <div className="filter-group">
          <label htmlFor="hashtag-filter">Hashtag</label>
          <input
            type="text"
            id="hashtag-filter"
            value={filters.hashtag}
            onChange={handleHashtagChange}
            placeholder="Filter by hashtag"
          />
        </div>

        <div className="filter-group">
          <label htmlFor="sentiment-filter">Sentiment</label>
          <select
            id="sentiment-filter"
            value={filters.sentiment}
            onChange={handleSentimentChange}
          >
            <option value="all">All Sentiments</option>
            <option value="positive">Positive</option>
            <option value="neutral">Neutral</option>
            <option value="negative">Negative</option>
          </select>
        </div>

        {competitorList.length > 0 && (
          <div className="filter-group">
            <label htmlFor="brand-filter">Brand</label>
            <select
              id="brand-filter"
              value={filters.brand}
              onChange={handleBrandChange}
            >
              <option value="all">All Brands</option>
              <option value={brandName}>{brandName}</option>
              {competitorList.map((competitor, index) => (
                <option key={index} value={competitor}>
                  {competitor}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardFilters;
