import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import './Dashboard.css';

const SentimentAnalysis = ({ data, brandName }) => {
  const pieChartRef = useRef(null);
  const lineChartRef = useRef(null);
  const pieChartInstance = useRef(null);
  const lineChartInstance = useRef(null);

  // Create charts for sentiment analysis
  useEffect(() => {
    if (!data || Object.keys(data).length === 0) return;

    // Combine sentiment data across platforms for the main brand
    const allSentiments = { positive: 0, neutral: 0, negative: 0 };
    
    Object.entries(data).forEach(([platform, platformData]) => {
      if (platformData[brandName]) {
        Object.entries(platformData[brandName]).forEach(([sentiment, count]) => {
          allSentiments[sentiment] += count;
        });
      }
    });
    
    // Prepare data for pie chart
    const pieData = {
      labels: ['Positive', 'Neutral', 'Negative'],
      datasets: [{
        data: [
          allSentiments.positive,
          allSentiments.neutral,
          allSentiments.negative
        ],
        backgroundColor: [
          'rgba(76, 175, 80, 0.7)',  // Green for positive
          'rgba(33, 150, 243, 0.7)',  // Blue for neutral
          'rgba(244, 67, 54, 0.7)'    // Red for negative
        ],
        borderColor: [
          'rgb(76, 175, 80)',
          'rgb(33, 150, 243)',
          'rgb(244, 67, 54)'
        ],
        borderWidth: 1
      }]
    };
    
    // Create or update pie chart
    if (pieChartInstance.current) {
      pieChartInstance.current.destroy();
    }
    
    const pieCtx = pieChartRef.current.getContext('2d');
    pieChartInstance.current = new Chart(pieCtx, {
      type: 'pie',
      data: pieData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
          },
          title: {
            display: true,
            text: 'Overall Sentiment Distribution'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const label = context.label || '';
                const value = context.raw || 0;
                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                const percentage = Math.round((value / total) * 100);
                return `${label}: ${value} (${percentage}%)`;
              }
            }
          }
        }
      }
    });
    
    // Create mock data for sentiment trend over time
    // In a real implementation, this would use actual timestamp data from the dataset
    const mockTimeData = {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [
        {
          label: 'Positive',
          data: [65, 70, 68, 75, 80, 85],
          borderColor: 'rgb(76, 175, 80)',
          backgroundColor: 'transparent',
          tension: 0.3
        },
        {
          label: 'Neutral',
          data: [30, 25, 28, 20, 18, 12],
          borderColor: 'rgb(33, 150, 243)',
          backgroundColor: 'transparent',
          tension: 0.3
        },
        {
          label: 'Negative',
          data: [5, 5, 4, 5, 2, 3],
          borderColor: 'rgb(244, 67, 54)',
          backgroundColor: 'transparent',
          tension: 0.3
        }
      ]
    };
    
    // Create or update line chart
    if (lineChartInstance.current) {
      lineChartInstance.current.destroy();
    }
    
    const lineCtx = lineChartRef.current.getContext('2d');
    lineChartInstance.current = new Chart(lineCtx, {
      type: 'line',
      data: mockTimeData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Sentiment Trend Over Time'
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Percentage (%)'
            },
            ticks: {
              callback: function(value) {
                return value + '%';
              }
            }
          },
          x: {
            title: {
              display: true,
              text: 'Month'
            }
          }
        }
      }
    });
    
    // Cleanup function
    return () => {
      if (pieChartInstance.current) {
        pieChartInstance.current.destroy();
      }
      if (lineChartInstance.current) {
        lineChartInstance.current.destroy();
      }
    };
  }, [data, brandName]);
  
  // Calculate sentiment percentages
  const calculatePercentages = () => {
    if (!data || Object.keys(data).length === 0) {
      return { positive: 0, neutral: 0, negative: 0 };
    }
    
    const allSentiments = { positive: 0, neutral: 0, negative: 0 };
    
    Object.entries(data).forEach(([platform, platformData]) => {
      if (platformData[brandName]) {
        Object.entries(platformData[brandName]).forEach(([sentiment, count]) => {
          allSentiments[sentiment] += count;
        });
      }
    });
    
    const total = Object.values(allSentiments).reduce((a, b) => a + b, 0);
    
    if (total === 0) {
      return { positive: 0, neutral: 0, negative: 0 };
    }
    
    return {
      positive: Math.round((allSentiments.positive / total) * 100),
      neutral: Math.round((allSentiments.neutral / total) * 100),
      negative: Math.round((allSentiments.negative / total) * 100)
    };
  };
  
  const percentages = calculatePercentages();
  
  return (
    <div className="dashboard-card">
      <div className="card-header">
        <div>
          <h2 className="card-title">Sentiment Analysis</h2>
          <p className="card-subtitle">Analysis of sentiment across social media posts</p>
        </div>
      </div>
      
      <div className="card-content" style={{ height: 'auto' }}>
        <div className="sentiment-overview">
          <h3>Overall Sentiment</h3>
          <div className="sentiment-bars">
            <div className="sentiment-bar">
              <div className="sentiment-label">Positive</div>
              <div className="progress-container">
                <div 
                  className="progress-bar positive" 
                  style={{ width: `${percentages.positive}%` }}
                ></div>
              </div>
              <div className="sentiment-percentage">{percentages.positive}%</div>
            </div>
            
            <div className="sentiment-bar">
              <div className="sentiment-label">Neutral</div>
              <div className="progress-container">
                <div 
                  className="progress-bar neutral" 
                  style={{ width: `${percentages.neutral}%` }}
                ></div>
              </div>
              <div className="sentiment-percentage">{percentages.neutral}%</div>
            </div>
            
            <div className="sentiment-bar">
              <div className="sentiment-label">Negative</div>
              <div className="progress-container">
                <div 
                  className="progress-bar negative" 
                  style={{ width: `${percentages.negative}%` }}
                ></div>
              </div>
              <div className="sentiment-percentage">{percentages.negative}%</div>
            </div>
          </div>
        </div>
        
        <div className="charts-container" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ height: '200px' }}>
            <canvas ref={pieChartRef}></canvas>
          </div>
          
          <div style={{ height: '200px' }}>
            <canvas ref={lineChartRef}></canvas>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SentimentAnalysis;
