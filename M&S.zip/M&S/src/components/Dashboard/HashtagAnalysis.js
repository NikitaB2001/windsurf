import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import './Dashboard.css';

const HashtagAnalysis = ({ data, brandName }) => {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  // Create chart for top hashtags
  useEffect(() => {
    if (!data || Object.keys(data).length === 0) return;

    // Combine hashtag data across platforms for the main brand
    const allHashtags = {};
    
    Object.entries(data).forEach(([platform, platformData]) => {
      if (platformData[brandName]) {
        Object.entries(platformData[brandName]).forEach(([hashtag, count]) => {
          if (!allHashtags[hashtag]) {
            allHashtags[hashtag] = 0;
          }
          allHashtags[hashtag] += count;
        });
      }
    });
    
    // Sort hashtags by count and get top 10
    const topHashtags = Object.entries(allHashtags)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10);
    
    // Prepare data for chart
    const labels = topHashtags.map(([hashtag]) => hashtag);
    const counts = topHashtags.map(([, count]) => count);
    
    // Create or update chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    const ctx = chartRef.current.getContext('2d');
    chartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Frequency',
          data: counts,
          backgroundColor: 'rgba(255, 87, 34, 0.7)',
          borderColor: 'rgb(255, 87, 34)',
          borderWidth: 1
        }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          title: {
            display: true,
            text: 'Top Performing Hashtags'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return `Count: ${context.raw}`;
              }
            }
          }
        },
        scales: {
          x: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Frequency'
            }
          },
          y: {
            title: {
              display: true,
              text: 'Hashtag'
            }
          }
        }
      }
    });
    
    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, brandName]);
  
  return (
    <div className="dashboard-card">
      <div className="card-header">
        <div>
          <h2 className="card-title">Top Performing Hashtags</h2>
          <p className="card-subtitle">Most frequently used hashtags with highest engagement</p>
        </div>
      </div>
      
      <div className="card-content">
        <canvas ref={chartRef}></canvas>
      </div>
    </div>
  );
};

export default HashtagAnalysis;
