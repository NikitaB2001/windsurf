import React, { useState, useEffect } from 'react';
import { loadAllData, processDataForDashboard } from '../../utils/dataProcessor';
import './Dashboard.css';
import BrandPerformance from './BrandPerformance';
import EngagementInsights from './EngagementInsights';
import HashtagAnalysis from './HashtagAnalysis';
import SentimentAnalysis from './SentimentAnalysis';
import CompetitorMonitoring from './CompetitorMonitoring';
import DashboardHeader from './DashboardHeader';
import DashboardFilters from './DashboardFilters';
import LoadingSpinner from './LoadingSpinner';

const Dashboard = ({ setupData }) => {
  const [dashboardData, setDashboardData] = useState(null);
  const [rawData, setRawData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    platform: 'all',
    dateRange: {
      startDate: null,
      endDate: null
    },
    hashtag: '',
    sentiment: 'all',
    brand: 'all'
  });

  // Load data when component mounts or setupData changes
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const { brandName, hashtags, competitors, selectedPlatforms } = setupData;
        
        // Load data from Excel files
        const data = await loadAllData(brandName, competitors, selectedPlatforms);
        setRawData(data);
        
        // Process data for dashboard
        const processedData = processDataForDashboard(data);
        setDashboardData(processedData);
      } catch (err) {
        console.error('Error loading dashboard data:', err);
        setError('Failed to load dashboard data. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };

    if (setupData) {
      fetchData();
    }
  }, [setupData]);

  // Apply filters when they change
  useEffect(() => {
    if (!rawData) return;

    // Apply filters to raw data
    // This is a simplified version - in a real app, you'd implement more sophisticated filtering
    const filteredData = { ...rawData };
    
    // Process filtered data
    const processedData = processDataForDashboard(filteredData);
    setDashboardData(processedData);
  }, [filters, rawData]);

  // Handle filter changes
  const handleFilterChange = (newFilters) => {
    setFilters({ ...filters, ...newFilters });
  };

  if (isLoading) {
    return <LoadingSpinner message="Loading dashboard data..." />;
  }

  if (error) {
    return <div className="dashboard-error">{error}</div>;
  }

  if (!dashboardData) {
    return <div className="dashboard-error">No data available. Please check your setup.</div>;
  }

  return (
    <div className="dashboard-container">
      <DashboardHeader brandName={setupData.brandName} />
      
      <DashboardFilters 
        filters={filters} 
        onFilterChange={handleFilterChange} 
        platforms={setupData.selectedPlatforms}
        brandName={setupData.brandName}
        competitors={setupData.competitors}
      />
      
      <div className="dashboard-grid">
        <div className="dashboard-row">
          <BrandPerformance 
            data={dashboardData.overallEngagement} 
            brandName={setupData.brandName}
            competitors={setupData.competitors}
          />
        </div>
        
        <div className="dashboard-row">
          <EngagementInsights 
            data={dashboardData.engagementRates}
            brandName={setupData.brandName}
            competitors={setupData.competitors}
          />
        </div>
        
        <div className="dashboard-row dashboard-split">
          <HashtagAnalysis 
            data={dashboardData.topHashtags}
            brandName={setupData.brandName}
          />
          
          <SentimentAnalysis 
            data={dashboardData.sentimentAnalysis}
            brandName={setupData.brandName}
          />
        </div>
        
        <div className="dashboard-row">
          <CompetitorMonitoring 
            data={dashboardData}
            brandName={setupData.brandName}
            competitors={setupData.competitors}
          />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
