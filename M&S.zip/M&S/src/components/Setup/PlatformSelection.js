import React from 'react';
import './Setup.css';

const PlatformSelection = ({ selectedPlatforms, setSelectedPlatforms, onNext, onBack }) => {
  const platforms = [
    { id: 'instagram', name: 'Instagram', icon: '📸' },
    { id: 'tiktok', name: 'TikTok', icon: '🎵' },
    { id: 'youtube', name: 'YouTube', icon: '▶️' }
  ];

  const handlePlatformToggle = (platformId) => {
    if (selectedPlatforms.includes(platformId)) {
      setSelectedPlatforms(selectedPlatforms.filter(id => id !== platformId));
    } else {
      setSelectedPlatforms([...selectedPlatforms, platformId]);
    }
  };

  return (
    <div className="setup-container">
      <div className="setup-header">
        <h2>Select Platforms to Monitor</h2>
        <p>Choose which social media platforms you want to include in your monitoring dashboard.</p>
      </div>

      <div className="setup-form">
        <div className="form-group">
          <label>Available Platforms</label>
          <div className="platform-options">
            {platforms.map(platform => (
              <div key={platform.id} className="platform-option">
                <input
                  type="checkbox"
                  id={platform.id}
                  checked={selectedPlatforms.includes(platform.id)}
                  onChange={() => handlePlatformToggle(platform.id)}
                />
                <label htmlFor={platform.id} className="platform-label">
                  <span className="platform-icon">{platform.icon}</span>
                  {platform.name}
                </label>
              </div>
            ))}
          </div>
          {selectedPlatforms.length === 0 && (
            <div className="validation-message">Please select at least one platform</div>
          )}
        </div>

        <div className="button-group">
          <button className="btn btn-secondary" onClick={onBack}>
            Back
          </button>
          <button
            className="btn btn-primary"
            onClick={onNext}
            disabled={selectedPlatforms.length === 0}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default PlatformSelection;
