import React from 'react';
import './Setup.css';

const ConfirmationModal = ({ 
  isOpen, 
  onClose, 
  onConfirm, 
  brandName, 
  hashtags, 
  competitors, 
  selectedPlatforms 
}) => {
  if (!isOpen) return null;

  // Format platform names for display
  const getPlatformName = (platformId) => {
    const platforms = {
      'instagram': 'Instagram',
      'tiktok': 'TikTok',
      'youtube': 'YouTube'
    };
    return platforms[platformId] || platformId;
  };

  // Parse competitors string into array
  const competitorList = competitors
    ? competitors.split(',').map(comp => comp.trim()).filter(comp => comp !== '')
    : [];

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>Confirm Your Setup</h3>
          <button className="modal-close" onClick={onClose}>&times;</button>
        </div>
        
        <div className="modal-body">
          <div className="summary-section">
            <h4>Main Brand</h4>
            <p>{brandName}</p>
          </div>
          
          <div className="summary-section">
            <h4>Selected Hashtags/Keywords</h4>
            <div className="tags-container">
              {hashtags.map((tag, index) => (
                <div key={index} className="tag">{tag}</div>
              ))}
            </div>
          </div>
          
          <div className="summary-section">
            <h4>Competitor Brands</h4>
            {competitorList.length > 0 ? (
              <div className="tags-container">
                {competitorList.map((comp, index) => (
                  <div key={index} className="tag">{comp}</div>
                ))}
              </div>
            ) : (
              <p>No competitors selected</p>
            )}
          </div>
          
          <div className="summary-section">
            <h4>Selected Platforms</h4>
            <div className="tags-container">
              {selectedPlatforms.map((platform, index) => (
                <div key={index} className="tag">{getPlatformName(platform)}</div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Edit Setup
          </button>
          <button className="btn btn-primary" onClick={onConfirm}>
            Confirm & Continue to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;
