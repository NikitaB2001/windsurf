import React, { useState, useEffect } from 'react';
import './Setup.css';
import * as XLSX from 'xlsx';

const CompetitorSetup = ({ competitors, setCompetitors, onNext, onBack }) => {
  const [competitorList, setCompetitorList] = useState([]);
  const [validationMessage, setValidationMessage] = useState('');
  const [isValidating, setIsValidating] = useState(false);
  const [validCompetitors, setValidCompetitors] = useState([]);
  const [invalidCompetitors, setInvalidCompetitors] = useState([]);

  // Parse competitors string into array when it changes
  useEffect(() => {
    if (competitors) {
      const parsedCompetitors = competitors
        .split(',')
        .map(comp => comp.trim())
        .filter(comp => comp !== '');
      
      setCompetitorList(parsedCompetitors);
    } else {
      setCompetitorList([]);
    }
  }, [competitors]);

  // Validate competitors against dataset
  const validateCompetitors = async () => {
    setIsValidating(true);
    setValidationMessage('');
    setValidCompetitors([]);
    setInvalidCompetitors([]);

    try {
      // In a real implementation, this would check against the dataset
      const dataFiles = [
        '/data/Insta_new_mandshashtags_cleaned.xlsx',
        '/data/Insta_new_marksandspencer_cleaned.xlsx',
        '/data/Insta_new_nexthashtags_cleaned.xlsx',
        '/data/Insta_new_nextofficial_cleaned_2.xlsx',
        '/data/dataset_tiktok-hashtag_M&S_cleaned.xlsx',
        '/data/dataset_tiktok-hashtag_NextRetail_cleaned.xlsx',
        '/data/dataset_tiktok_M&S_official_cleaned.xlsx',
        '/data/dataset_youtube-Hashtag_M&S 1_cleaned.xlsx',
        '/data/dataset_youtube-Hashtag_Next 1_cleaned.xlsx',
        '/data/dataset_youtube-channel-scraper_M&S-official 1_cleaned.xlsx',
        '/data/dataset_youtube-channel-scraper_NextRetail-Official 1_cleaned.xlsx',
        '/data/tiktok_NEXT_Official_cleaned.xlsx'
      ];

      // Function to check if a competitor exists in the dataset
      const checkCompetitorInDataset = async (competitor) => {
        const competitorLower = competitor.toLowerCase();
        
        // Check if competitor name appears in file names
        const relevantFiles = dataFiles.filter(file => 
          file.toLowerCase().includes(competitorLower.replace(/\s+/g, '')) ||
          file.toLowerCase().includes(competitorLower.replace(/\s+/g, '-'))
        );
        
        if (relevantFiles.length > 0) {
          return true;
        }
        
        // If not found in file names, check content of files
        // This is a simplified approach - in a real app, we'd do more thorough validation
        for (const filePath of dataFiles) {
          try {
            const response = await fetch(filePath);
            const data = await response.arrayBuffer();
            const workbook = XLSX.read(data, { type: 'array' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet);
            
            // Check various columns that might contain competitor mentions
            const textColumns = ['caption', 'description', 'text', 'title'];
            
            for (const row of jsonData) {
              for (const column of textColumns) {
                if (row[column] && 
                    row[column].toString().toLowerCase().includes(competitorLower)) {
                  return true;
                }
              }
            }
          } catch (error) {
            console.error(`Error processing ${filePath}:`, error);
          }
        }
        
        return false;
      };
      
      // Validate each competitor
      const validationResults = await Promise.all(
        competitorList.map(async (competitor) => {
          const isValid = await checkCompetitorInDataset(competitor);
          return { competitor, isValid };
        })
      );
      
      const valid = validationResults.filter(result => result.isValid).map(result => result.competitor);
      const invalid = validationResults.filter(result => !result.isValid).map(result => result.competitor);
      
      setValidCompetitors(valid);
      setInvalidCompetitors(invalid);
      
      if (invalid.length > 0) {
        setValidationMessage(`Some competitors were not found in the dataset: ${invalid.join(', ')}`);
      } else if (valid.length > 0) {
        setValidationMessage('All competitors validated successfully!');
      } else {
        setValidationMessage('Please enter at least one competitor.');
      }
    } catch (error) {
      console.error('Error validating competitors:', error);
      setValidationMessage('An error occurred during validation. Please try again.');
    } finally {
      setIsValidating(false);
    }
  };

  const handleInputChange = (e) => {
    setCompetitors(e.target.value);
    // Clear validation when input changes
    setValidationMessage('');
    setValidCompetitors([]);
    setInvalidCompetitors([]);
  };

  const handleContinue = () => {
    // If we have valid competitors or user wants to proceed anyway
    if (validCompetitors.length > 0 || competitorList.length === 0) {
      onNext();
    } else {
      validateCompetitors();
    }
  };

  return (
    <div className="setup-container">
      <div className="setup-header">
        <h2>Add Competitor Brands</h2>
        <p>Enter competitor brand names separated by commas. We'll validate these against our dataset.</p>
      </div>

      <div className="setup-form">
        <div className="form-group">
          <label htmlFor="competitors">Competitor Brands</label>
          <textarea
            id="competitors"
            value={competitors}
            onChange={handleInputChange}
            placeholder="e.g., Next Retail, Primark, ASOS"
            className="form-control"
            rows={3}
          />
          <p className="form-text">Enter multiple competitors separated by commas</p>
        </div>

        {validationMessage && (
          <div className={`validation-message ${!invalidCompetitors.length ? 'success-message' : ''}`}>
            {validationMessage}
          </div>
        )}

        {validCompetitors.length > 0 && (
          <div className="form-group">
            <label>Valid Competitors</label>
            <div className="tags-container">
              {validCompetitors.map((comp, index) => (
                <div key={index} className="tag valid-tag">
                  {comp} ✓
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="button-group">
          <button className="btn btn-secondary" onClick={onBack}>
            Back
          </button>
          
          <div>
            <button 
              className="btn btn-secondary" 
              onClick={validateCompetitors}
              disabled={isValidating || competitorList.length === 0}
              style={{ marginRight: '10px' }}
            >
              {isValidating ? (
                <>
                  <span className="spinner"></span> Validating...
                </>
              ) : (
                'Validate'
              )}
            </button>
            
            <button 
              className="btn btn-primary" 
              onClick={handleContinue}
              disabled={isValidating}
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompetitorSetup;
