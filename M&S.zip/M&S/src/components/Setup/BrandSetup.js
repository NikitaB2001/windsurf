import React, { useState, useEffect } from 'react';
import './Setup.css';
import * as XLSX from 'xlsx';

const BrandSetup = ({ brandName, setBrandName, hashtags, setHashtags, onNext }) => {
  const [suggestedHashtags, setSuggestedHashtags] = useState([]);
  const [newHashtag, setNewHashtag] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  // Generate hashtags based on the brand name from the dataset
  useEffect(() => {
    if (brandName) {
      setIsLoading(true);
      generateHashtagsFromDataset(brandName)
        .then(tags => {
          setSuggestedHashtags(tags);
          // Initialize hashtags if empty
          if (!hashtags || hashtags.length === 0) {
            setHashtags(tags.slice(0, 5)); // Set first 5 as default
          }
        })
        .catch(err => {
          console.error('Error generating hashtags:', err);
          setError('Failed to generate hashtags. Please try again.');
        })
        .finally(() => {
          setIsLoading(false);
        });
    }
  }, [brandName]);

  // Function to extract hashtags from dataset based on brand name
  const generateHashtagsFromDataset = async (brand) => {
    try {
      const brandLower = brand.toLowerCase();
      const dataFiles = [
        '/data/Insta_new_mandshashtags_cleaned.xlsx',
        '/data/Insta_new_nexthashtags_cleaned.xlsx',
        '/data/dataset_tiktok-hashtag_M&S_cleaned.xlsx',
        '/data/dataset_tiktok-hashtag_NextRetail_cleaned.xlsx',
        '/data/dataset_youtube-Hashtag_M&S 1_cleaned.xlsx',
        '/data/dataset_youtube-Hashtag_Next 1_cleaned.xlsx'
      ];
      
      let relevantFiles = [];
      
      // Determine which files to use based on brand name
      if (brandLower.includes('marks') || brandLower.includes('spencer') || brandLower.includes('m&s')) {
        relevantFiles = dataFiles.filter(file => 
          file.toLowerCase().includes('mands') || 
          file.toLowerCase().includes('m&s')
        );
      } else if (brandLower.includes('next')) {
        relevantFiles = dataFiles.filter(file => 
          file.toLowerCase().includes('next') && 
          !file.toLowerCase().includes('m&s')
        );
      }
      
      if (relevantFiles.length === 0) {
        // If no specific files match, use all hashtag files
        relevantFiles = dataFiles;
      }
      
      // Function to load and process a file
      const processFile = async (filePath) => {
        const response = await fetch(filePath);
        const data = await response.arrayBuffer();
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        // Extract hashtags from different possible columns
        const hashtagColumns = ['hashtags', 'hashtag', 'description', 'caption', 'text'];
        let extractedTags = [];
        
        jsonData.forEach(row => {
          hashtagColumns.forEach(column => {
            if (row[column]) {
              const text = row[column].toString();
              const tags = text.match(/#[a-zA-Z0-9_]+/g) || [];
              extractedTags = [...extractedTags, ...tags];
            }
          });
        });
        
        return extractedTags;
      };
      
      // Process all relevant files and collect hashtags
      const allHashtagPromises = relevantFiles.map(processFile);
      const hashtagArrays = await Promise.all(allHashtagPromises);
      
      // Flatten arrays and count occurrences
      const allHashtags = hashtagArrays.flat();
      const hashtagCounts = {};
      
      allHashtags.forEach(tag => {
        if (hashtagCounts[tag]) {
          hashtagCounts[tag]++;
        } else {
          hashtagCounts[tag] = 1;
        }
      });
      
      // Sort by frequency and return top hashtags
      const sortedHashtags = Object.entries(hashtagCounts)
        .sort((a, b) => b[1] - a[1])
        .map(entry => entry[0]);
      
      // Filter to ensure they're relevant to the brand
      const brandTerms = brand.toLowerCase().split(' ');
      const relevantHashtags = sortedHashtags.filter(tag => {
        const tagText = tag.toLowerCase().substring(1); // Remove # symbol
        return brandTerms.some(term => tagText.includes(term)) || 
               tagText.length > 3; // Include longer hashtags that might be relevant
      });
      
      return relevantHashtags.slice(0, 20); // Return top 20 hashtags
    } catch (error) {
      console.error('Error processing dataset for hashtags:', error);
      return [];
    }
  };

  const handleAddHashtag = () => {
    if (newHashtag && !hashtags.includes(newHashtag)) {
      const formattedHashtag = newHashtag.startsWith('#') ? newHashtag : `#${newHashtag}`;
      setHashtags([...hashtags, formattedHashtag]);
      setNewHashtag('');
    }
  };

  const handleRemoveHashtag = (tagToRemove) => {
    setHashtags(hashtags.filter(tag => tag !== tagToRemove));
  };

  const handleSuggestedHashtagClick = (tag) => {
    if (!hashtags.includes(tag)) {
      setHashtags([...hashtags, tag]);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleAddHashtag();
      e.preventDefault();
    }
  };

  return (
    <div className="setup-container">
      <div className="setup-header">
        <h2>What brand would you like to monitor?</h2>
        <p>Enter your main brand name. We'll use this to generate relevant keywords and hashtags to track across social media platforms.</p>
      </div>

      <div className="setup-form">
        <div className="form-group">
          <label htmlFor="brandName">Brand Name</label>
          <input
            type="text"
            id="brandName"
            value={brandName}
            onChange={(e) => setBrandName(e.target.value)}
            placeholder="e.g., Marks & Spencer"
            className="form-control"
          />
          <p className="form-text">Examples: Nike, Starbucks, Apple Inc., Tesla</p>
        </div>

        {brandName && (
          <>
            <div className="form-group">
              <label>Selected Hashtags/Keywords</label>
              <div className="tags-container">
                {hashtags.map((tag, index) => (
                  <div key={index} className="tag">
                    {tag}
                    <button onClick={() => handleRemoveHashtag(tag)}>×</button>
                  </div>
                ))}
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="newHashtag">Add Custom Hashtag/Keyword</label>
              <div className="input-group">
                <input
                  type="text"
                  id="newHashtag"
                  value={newHashtag}
                  onChange={(e) => setNewHashtag(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Enter hashtag or keyword"
                  className="form-control"
                />
                <button onClick={handleAddHashtag} className="btn btn-secondary">Add</button>
              </div>
            </div>

            {isLoading ? (
              <div className="loading">
                <span className="spinner"></span> Generating suggested hashtags...
              </div>
            ) : (
              suggestedHashtags.length > 0 && (
                <div className="form-group">
                  <label>Suggested Hashtags (click to add)</label>
                  <div className="tags-container suggested-tags">
                    {suggestedHashtags
                      .filter(tag => !hashtags.includes(tag))
                      .slice(0, 10)
                      .map((tag, index) => (
                        <div 
                          key={index} 
                          className="tag suggested-tag" 
                          onClick={() => handleSuggestedHashtagClick(tag)}
                        >
                          {tag}
                        </div>
                      ))}
                  </div>
                </div>
              )
            )}

            {error && <div className="validation-message">{error}</div>}
          </>
        )}

        <div className="button-group">
          <button 
            className="btn btn-primary" 
            onClick={onNext}
            disabled={!brandName || hashtags.length === 0}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default BrandSetup;
