import React, { useState } from 'react';
import BrandSetup from './BrandSetup';
import CompetitorSetup from './CompetitorSetup';
import PlatformSelection from './PlatformSelection';
import ConfirmationModal from './ConfirmationModal';
import './Setup.css';

const SetupWizard = ({ onComplete }) => {
  // Setup state
  const [currentStep, setCurrentStep] = useState(1);
  const [brandName, setBrandName] = useState('');
  const [hashtags, setHashtags] = useState([]);
  const [competitors, setCompetitors] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Progress through setup steps
  const goToNextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      // Open confirmation modal after final step
      setIsModalOpen(true);
    }
  };

  const goToPreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  // Handle confirmation and completion
  const handleConfirm = () => {
    // Prepare data to pass to dashboard
    const setupData = {
      brandName,
      hashtags,
      competitors,
      selectedPlatforms
    };
    
    // Close modal and complete setup
    setIsModalOpen(false);
    onComplete(setupData);
  };

  // Render progress indicator
  const renderProgressIndicator = () => {
    return (
      <div className="progress-indicator">
        {[1, 2, 3].map(step => (
          <React.Fragment key={step}>
            {step > 1 && (
              <div className={`step-connector ${step <= currentStep ? 'active' : ''}`}></div>
            )}
            <div className={`step ${step === currentStep ? 'active' : step < currentStep ? 'completed' : ''}`}>
              {step}
            </div>
          </React.Fragment>
        ))}
      </div>
    );
  };

  // Render current step
  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <BrandSetup
            brandName={brandName}
            setBrandName={setBrandName}
            hashtags={hashtags}
            setHashtags={setHashtags}
            onNext={goToNextStep}
          />
        );
      case 2:
        return (
          <CompetitorSetup
            competitors={competitors}
            setCompetitors={setCompetitors}
            onNext={goToNextStep}
            onBack={goToPreviousStep}
          />
        );
      case 3:
        return (
          <PlatformSelection
            selectedPlatforms={selectedPlatforms}
            setSelectedPlatforms={setSelectedPlatforms}
            onNext={goToNextStep}
            onBack={goToPreviousStep}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="setup-wizard">
      {renderProgressIndicator()}
      {renderCurrentStep()}
      
      <ConfirmationModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConfirm={handleConfirm}
        brandName={brandName}
        hashtags={hashtags}
        competitors={competitors}
        selectedPlatforms={selectedPlatforms}
      />
    </div>
  );
};

export default SetupWizard;
